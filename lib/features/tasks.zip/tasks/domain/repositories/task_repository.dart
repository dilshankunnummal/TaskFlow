import 'package:dartz/dartz.dart' hide Task;
import 'package:taskflow/core/error/failures.dart';
import 'package:taskflow/features/tasks/domain/entities/task.dart';

abstract class TaskRepository {
  Future<Either<Failure, List<Task>>> getTasksByProject({required String projectId});

  Future<Either<Failure, List<Task>>> refreshTasks({required String projectId});
}